//
//  ViewController.swift
//  Test
//
//  Created by Hayden on 16/4/6.
//  Copyright © 2016年 University of Melbourne. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        
        // XML字符串，用来作为POST的参数发送
        let xmlString =
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
            "<csw:GetRecords" +
            "    service=\"CSW\"" +
            "    version=\"2.0.2\"" +
            "    resultType=\"hints\"" +
            "    outputSchema=\"http://www.opengis.net/cat/csw/2.0.2\"" +
            "    xmlns:ogc=\"http://www.opengis.net/ogc\"" +
            "    xmlns:csw=\"http://www.opengis.net/cat/csw/2.0.2\"" +
            "    xmlns:gml=\"http://www.opengis.net/gml\">" +
            "    <csw:Query typeNames=\"csw:Record\">" +
            "        <csw:ElementSetName>full</csw:ElementSetName>" +
            "        <csw:Constraint version=\"1.1.0\">" +
            "            <ogc:Filter>" +
            "                <ogc:BBOX>" +
            "                    <ogc:PropertyName>ows:BoundingBox</ogc:PropertyName>" +
            "                    <gml:Envelope>" +
            "                        <gml:lowerCorner>-45.0 100.0</gml:lowerCorner>" +
            "                        <gml:upperCorner>-0.0 140.0</gml:upperCorner>" +
            "                    </gml:Envelope>" +
            "                </ogc:BBOX>" +
            "            </ogc:Filter>" +
            "        </csw:Constraint>" +
            "    </csw:Query>" +
            "</csw:GetRecords>"
        
        // 发送请求的URL
        let URLString = "http://openapi.aurin.org.au/csw?service=CSW&request=GetRecords&typeNames=csw:Record"
        
        // 用Alamofire发送XML到服务器，请求数据
        // Alamofire定义了Parameter Encoding的方法，可以传JOSN等参数，但是XML没有写，要自己定义Custom。
        // 文档中的说明：
        //   > Custom: Uses the associated closure value to construct a new request given an existing request and parameters.
        //   > Custom((URLRequestConvertible, [String: AnyObject]?) -> (NSMutableURLRequest, NSError?))
        Alamofire.request(.POST, URLString, parameters: nil, encoding: .Custom({
                (convertible, params) in
                    //a.
                    let mutableRequest = convertible.URLRequest.copy() as! NSMutableURLRequest
                    // or
                    //b.
                    mutableRequest.URL = NSURL(string: URLString)
                    mutableRequest.HTTPBody = xmlString.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: false)
                    return (mutableRequest, nil)}))
            .authenticate(user: "student", password: "dj78dfGF")
            .response{ (request, response, data, error) in
                            let xml = SWXMLHash.parse(data!)
                            print(xml)
                     }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

